# Translation decisions and idiom glossary

Authoritative. If a rule here conflicts with what looks natural, follow the rule
and log the conflict in `OPEN-QUESTIONS.md`.

## Governing principle

Where two Python idioms are otherwise equally good, choose the one that maps more
visibly onto the R tab. The book teaches operations, not syntax, and the tabset is
the mechanism by which a student sees the operation behind both languages. This is
a deliberate choice with a known cost: some idioms here are not the most common in
the wider Python ecosystem.

## Stack

| Purpose | R | Python | Notes |
|---|---|---|---|
| Data frames | dplyr / tidyr | pandas | Not polars. Not both. |
| Plotting | ggplot2 | plotnine | Not matplotlib or seaborn. |
| Models | stats / broom | statsmodels (formula API) | Preserves the `y ~ x` narrative. |
| Arrays and numerics | base R | numpy | |
| Distributions and tests | stats | scipy.stats | |

Version floor: pandas >= 2.2, plotnine >= 0.13. Record the actual pinned versions
in `requirements.txt` once the setup chapter is written.

## Import block

Every chapter's first Python tab repeats this block; later chunks in the chapter
assume it.

```python
import pandas as pd
import numpy as np
from plotnine import *
import statsmodels.formula.api as smf
```

`from plotnine import *` is a deliberate exception to normal practice: it keeps
`ggplot(...) + geom_point()` visually parallel to the R tab. Do not use a wildcard
import for any other library.

## Style conventions

- snake_case throughout. Where an R object name contains a dot, replace it with an
  underscore and change nothing else (`penguins.clean` becomes `penguins_clean`).
- Otherwise preserve R variable names exactly, so the two tabs read side by side.
- Mirror the pipe with a parenthesised method chain, one method per line, using
  `.loc[lambda ...]` for row filtering and `.assign()` for column creation:

  ```python
  (
      penguins
      .loc[lambda d: d["body_mass_g"] > 3000]
      .assign(mass_kg=lambda d: d["body_mass_g"] / 1000)
      .groupby("species", as_index=False)
      .agg(mean_mass=("mass_kg", "mean"))
  )
  ```

  Not `.query()`: its condition is a string, so errors are opaque and editors
  cannot check it. Not bare masking (`d[d["x"] > 3]`): it breaks the chain and
  invites `SettingWithCopyWarning`.
- No `inplace=True`. Ever.
- Four-space indentation, double-quoted strings.
- In a `ggplot` translation, place the leading `+` at the start of each
  continuation line so the layers stack visibly, as they do in the R tab.
- Comments in the R chunk are carried across verbatim where they still apply.

## Idiom glossary

Extend this table from the chapter inventory before bulk work starts. Any idiom
not listed goes through the ambiguity protocol in `CLAUDE.md`.

| R | Python |
|---|---|
| `read_csv("f.csv")` | `pd.read_csv("f.csv")` |
| `filter(x > 3)` | `.loc[lambda d: d["x"] > 3]` |
| `select(a, b)` | `[["a", "b"]]` |
| `mutate(z = x + y)` | `.assign(z=lambda d: d["x"] + d["y"])` |
| `rename(new = old)` | `.rename(columns={"old": "new"})` |
| `arrange(x)` | `.sort_values("x")` |
| `arrange(desc(x))` | `.sort_values("x", ascending=False)` |
| `summarise(m = mean(x), .by = g)` | `.groupby("g", as_index=False).agg(m=("x", "mean"))` |
| `count(g)` | `.groupby("g", as_index=False).size().rename(columns={"size": "n"})` |
| `left_join(y, by = join_by(id))` | `.merge(y, on="id", how="left")` |
| `pivot_longer(cols, names_to, values_to)` | `.melt(id_vars=..., var_name=..., value_name=...)` |
| `pivot_wider(names_from, values_from)` | `.pivot(index=..., columns=..., values=...)` |
| `distinct()` | `.drop_duplicates()` |
| `drop_na()` | `.dropna()` |
| `n()` | `"size"` inside `.agg()` |
| `head(6)` | `.head(6)` |
| `nrow(df)` | `len(df)` |
| `ncol(df)` | `df.shape[1]` |
| `glimpse(df)` | `df.info()` |
| `ggplot(d, aes(x, y))` | `ggplot(d, aes("x", "y"))` - aesthetics are strings |
| `facet_wrap(~g)` | `facet_wrap("g")` |
| `labs(x =, y =, title =)` | `labs(x=, y=, title=)` |
| `theme_minimal()` | `theme_minimal()` |
| `lm(y ~ x, data = d)` | `smf.ols("y ~ x", data=d).fit()` |
| `summary(model)` | `model.summary()` |
| `t.test(x, y)` | `stats.ttest_ind(x, y)` |
| `seq(1, 10)` | `np.arange(1, 11)` |
| `rep(0, 5)` | `np.zeros(5)` |

## Standing warnings

These belong in the preface, stated once, not repeated per chunk:

- Indexing is 0-based and slices are half-open, so any positional example differs.
- Random number streams differ. Any chunk using `set.seed()` produces different
  values in Python; the Python tab shows the method, not reproducible output.
- `NA` and `NaN` are not equivalent, and `mean()` skips missing values by default
  in pandas but not in base R.
- pandas has view-versus-copy semantics with no dplyr analogue.
- Locale-dependent string sorting differs.
- plotnine and ggplot2 differ in default palette, typeface, point size and legend
  placement. Figures will look similar, not identical.
